// ProjectCard.jsx
// Displays a single project with image, title, description and expand/collapse toggle

import React from 'react'
import Card from '../ui/Card/Card'
import CardHeader from '../ui/Card/CardHeader'
import CardMedia from '../ui/Card/CardMedia'
import CardBody from '../ui/Card/CardBody'
import CardFooter from '../ui/Card/CardFooter'
import Button from '../ui/Button'
import useToggle from '../../hooks/useToggle'
import { truncateText } from '../../utils/formatters'

function ProjectCard(props) {
  const project = props.project
  // useToggle controls whether full description is shown or truncated
  const [expanded, toggleExpanded] = useToggle(false)

  return (
    <Card className="project-card">
      {/* Project image */}
      <CardMedia src={'/images/projects/' + project.image} alt={project.title + ' project'} />
      {/* Project title */}
      <CardHeader title={project.title} />
      <CardBody>
        {/* Show truncated or full description based on expanded state */}
        <p>{expanded ? project.description : truncateText(project.description, 100)}</p>
      </CardBody>
      <CardFooter>
        {/* Toggle button to expand or collapse description */}
        <Button label={expanded ? 'Show Less' : 'Read More'} onClick={toggleExpanded} className="btn-primary" />
      </CardFooter>
    </Card>
  )
}

export default ProjectCard