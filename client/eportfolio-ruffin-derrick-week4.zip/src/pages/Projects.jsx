// Projects.jsx
// Projects page that renders each project as a ProjectCard

import React from 'react'
import projectsData from '../data/projects.json'
import ProjectCard from '../components/cards/ProjectCard'

function Projects() {
  return (
    <main>
      <section>
        <h2>Projects</h2>
        {/* Render each project from JSON as a ProjectCard */}
        <div className="projects-container">
          {projectsData.map(function(project) {
            return (<ProjectCard key={project.id} project={project} />)
          })}
        </div>
      </section>
    </main>
  )
}

export default Projects